/**
 * 
 */
package cn.javass.c16.dao.dao;

/**
 * @author wushensi
 *
 */
public interface DepDAO {
	public void create(String userid,String username);

}
