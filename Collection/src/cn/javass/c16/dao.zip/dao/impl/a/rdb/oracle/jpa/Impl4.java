package cn.javass.c16.dao.impl.a.rdb.oracle.jpa;

import cn.javass.c16.dao.dao.DepDAO;

public class Impl4 implements DepDAO {

	@Override
	public void create(String userid, String username) {
		// TODO Auto-generated method stub
		System.out.println("Impl444444"+"---userid---"+userid+"---username---"+username);
	}

}
