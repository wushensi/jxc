package cn.javass.c16.dao.impl.a.rdb.oracle.hibernate;

import cn.javass.c16.dao.dao.DepDAO;

public class Impl2 implements DepDAO{

	@Override
	public void create(String userid, String username) {
		// TODO Auto-generated method stub
		System.out.println("Impl222222"+"---userid---"+userid+"---username---"+username);
	}

}
