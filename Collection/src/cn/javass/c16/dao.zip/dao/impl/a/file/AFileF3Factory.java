package cn.javass.c16.dao.impl.a.file;

import cn.javass.c16.dao.dao.DepDAO;

public class AFileF3Factory {
	public static DepDAO getDepDAO(){
		return null;
	}
}
