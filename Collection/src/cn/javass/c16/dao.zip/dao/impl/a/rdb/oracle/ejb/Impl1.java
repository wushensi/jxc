package cn.javass.c16.dao.impl.a.rdb.oracle.ejb;

import cn.javass.c16.dao.dao.DepDAO;

public class Impl1 implements DepDAO {

	@Override
	public void create(String userid, String username) {
		// TODO Auto-generated method stub
		System.out.println("Impl11111111"+"---userid---"+userid+"---username---"+username);
	}

}
