package cn.javass.c16.dao.impl.b;

import cn.javass.c16.dao.dao.DepDAO;

public class BF2Factory {
	public static DepDAO getDepDAO(){
		return null;
	}
}
